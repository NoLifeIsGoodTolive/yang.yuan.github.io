let app = require('express')();
let http = require('http').createServer(app);
let io = require('socket.io')(http);

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

let userIndex = 0;
let Names = ["Mike", "Sissi", "Sam", "Frodo", "Gandalf"];
let clientList = [];
let history = [];

io.on('connection', function(socket){
  const time = new Date().toLocaleTimeString('en-GB', { hour: "numeric", 
                                             minute: "numeric"});
//
  socket.on('chat message', function(msgFull){
    let msg = msgFull.info;
    let input = msg.toString();

    if (input.includes("/nickcolor") ){
      let temp = msg.split(" ");

      if (temp.length === 2) {
        let newColor = temp[1];
        console.log(newColor);

        io.emit('color change', {
          color : newColor,
          id: socket.username
        });   
      }
    } else if (input.includes("/nick")){   
      let oddname = socket.username;
      let temp = msg.split(" ");

      if (temp.length === 2){
        let newName = temp[1];

        let unique = True ;
        for (let val of Names){
          if (val === newName)
            unique = False;
        }

        if (unique){
          io.emit('name change', {
            oddname : socket.username,
            newname : newName
          });
          socket.username = newName;
        }
      }
    }
    else {
      let text = time + '  ' + socket.username + ' : ' + msg;
      history.push(text);
      io.emit('chat message', {
        time: time,
        info: msg,
        id: socket.username,
        color: msgFull.color
      });
    }
  });

//
  socket.on('add user', function(){
    io.emit('add user', {
      index: userIndex,
      nickName: Names[userIndex]
    });

    socket.username = Names[userIndex];
    clientList.push(socket.username);
  
    io.emit('UsersOn', clientList);
    ++userIndex;

    socket.emit('send history', history);

  });

//
  socket.on('disconnect', function(){
    io.emit('someone left', socket.username);
  });


});

http.listen(3000, function(){
  console.log('listening on *:3000');
});
